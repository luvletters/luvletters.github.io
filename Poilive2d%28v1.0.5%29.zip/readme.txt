﻿=== PoiLive2D ===
Contributors: 戴兜
Tags: html5, live2d, 人偶, 看板娘
Requires at least: 3.5
Tested up to: 4.9.7
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

添加一个Live2D人物在你的博客里

== Description ==

添加一个Live2D人物在你的博客里
模型均来自手游 药水制作师
详细介绍： https://daidr.me/archives/code-176.html


== Installation ==

1. 上传 插件 到 `/wp-content/plugins/` 目录
2. 在后台插件菜单激活该插件

== Changelog ==

= 1.0.5 =
* 修复后台异常输出
* 优化代码结构
* 增加换装功能

= 1.0.4 =
* 修复设置页面json保存后出现反斜杠的问题

= 1.0.2 =
* 修复header错误输出的问题

= 1.0.1 =
* 新增插件设置页面

= 1.0.0 =
* 初始版本发布